# QueryConsolidatorFXML

SQL Server is required to run this program.  
Two database sql server scripts can be run to add the instance/database to sql server, QueryConsilidate_APPSWPRAC and 
QueryConsolidate_APPSWPRAC2.  They are identical scripts, the only difference being one is for the Server/Instance APPSWPRAC and
the other is APPSWPRAC2.  The user can add data to the tables (which would typically be different) as they see fit.  

